Chapter 1:    en-us.lang.php
              Opportunities Screen 
              Config.php  
              Style.css 
Chapter 2:    Module.php 
              Opportunities module  
              PPIDashlet.meta.php 
              PPIDashlet.php 
Chapter 3:    Customfield 
              Editview.html 
              vardefs.php 
Chapter 4:    index.php 
              vardefs.php 
              Opportunity.php 

Chapter 5 & Chapter 6: No Code

Chapter 7:    config.php 
              LinuxScripting 
Chapter 8:    Menu.php 
              en_us.lang.php 
              index.php 
              Menu.phpchanged 
              dictionary 
              ppi_report_manager.php 
              en_Us.lang.php(modified Vname)
              listviewdefs.php 
              listview.php 
              index.php(modified listview)
              EditView.php 
              Editview.html 
              save.php 
              Menu.php(edited)
Chapter 9:    en_us.lang.php 
              logic_hook.php 
              ppi_workflow.php 
              ppi_workflow(Changed)
              Adding dependence task 
Chapter 10:   Modifying preliminary investigation.php 